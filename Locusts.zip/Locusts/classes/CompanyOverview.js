class CompanyOverview {
    constructor(sector, industry, employeesNb, address) {
        this.sector = "";
        this.industry = "";
        this.employeesNb = "";
        this.address = [];
    }
  }
  
  module.exports = CompanyOverview;